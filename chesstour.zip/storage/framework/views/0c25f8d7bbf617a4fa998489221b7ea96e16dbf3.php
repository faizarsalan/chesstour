<?php $__env->startSection('content'); ?>
<h1 class="title">Time Controls</h1>
        <table id="tablestyle">
          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">Time Control Name</th>
              <th scope="col">Inial Time</th>
              <th scope="col">Increment Time</th>
              <th scope="col">Category Name</th>
              <th scope="col">Action</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($model->id_Time_Control); ?></td>
                <td><?php echo e($model->name); ?></td>
                <td><?php echo e($model->initialtime); ?></td>
                <td><?php echo e($model->incrementtime); ?></td>
                <td><?php echo e($model->categoryname); ?></td>
                <td><button class="agree"><a href="#open-update<?php echo e($i); ?>">edit</a></button></td>
                <td>
                  <form action="/time/remove/<?php echo e($model->id_Time_Control); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                    <div>
                      <button class="remove" type="submit">remove</button>
                    </div>
                  </form>
                </td>
                <div id="open-update<?php echo e($i); ?>" class="modal-window">
                  <div class="outside">
                      <div class="inside">
                          <a href="#" title="Close" class="modal-close" style="margin-bottom: 5vh">X</a>
                          <h1>Edit the Time Control!</h1>
                          <form action="/time/update/<?php echo e($model->id_Time_Control); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <label for="Name">Name</label>
                            <input required type="text" name="name" id="" value="<?php echo e($model->name); ?>">
                            <label for="initialtime">Initial Time</label>
                            <input required type="text" name="initialtime" id="" value="<?php echo e($model->initialtime); ?>">
                            <label for="incrementtime">Increment Time</label>
                            <input required type="text" name="incrementtime" id="" value="<?php echo e($model->incrementtime); ?>">
                            <label for="category">Category</label>
                            <select name="category" id="">
                                <?php $__currentLoopData = $datacat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id_Category); ?>" <?php echo e(( $model->categoryname == $item->name) ? 'selected' : ''); ?>> <?php echo e($item->name); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input required type="hidden" name="id" value="<?php echo e($model->id_Time_Control); ?>">

                            <button type="submit"
                            style="width: 5.5vw;background-color:#28A745;height:2vw;border-radius:1vw;border:none;color:white">Save</button>
                        </form>
                      </div>
                  </div>
              </div>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>


      <a href="/time/add" class="act-btn">
        +
      </a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfars\Documents\chesstour\resources\views/timecontrollist.blade.php ENDPATH**/ ?>