<?php $__env->startSection('content'); ?>
  <h1 class="title">Categories</h1>
        <table id="tablestyle">
          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">Name</th>
              <th scope="col">Actions</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($model->id_Category); ?></td>
                <td><?php echo e($model->name); ?></td>
                <td><button class="agree"><a href="#open-update<?php echo e($i); ?>">edit</a></button></td>
                <td>
                  <form action="/category/remove/<?php echo e($model->id_Category); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                    <div>
                      <button class="remove" type="submit">remove</button>
                    </div>
                  </form>
                </td>
                <div id="open-update<?php echo e($i); ?>" class="modal-window">
                  <div class="outside">
                      <div class="inside">
                          <a href="#" title="Close" class="modal-close" style="margin-bottom: 5vh">X</a>
                          <h1>Edit the Category!</h1>
                          <form action="/category/update/<?php echo e($model->id_Category); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <label for="name">Name</label>
                            <input type="text" name="name" id="" value="<?php echo e($model->name); ?>">
                            <input type="hidden" name="id" value="<?php echo e($model->id_Category); ?>">

                            <button type="submit"
                            style="width: 5.5vw;background-color:#28A745;height:2vw;border-radius:1vw;border:none;color:white">Save</button>
                        </form>
                      </div>
                  </div>
              </div>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>


      <a href="/category/add" class="act-btn">
        +
      </a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfars\Documents\chesstour\resources\views/categorylist.blade.php ENDPATH**/ ?>