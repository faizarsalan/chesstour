<?php $__env->startSection('content'); ?>
<h1 class="title">Tournaments</h1>
        <table id="tablestyle">
          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">Tournament Name</th>
              <th scope="col">Prize Pool</th>
              <th scope="col">Venue Name</th>
              <th scope="col">Organizer Name</th>
              <th scope="col">Time Control</th>
              <th scope="col">Action</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($model->id_Tournament); ?></td>
                <td><?php echo e($model->name); ?></td>
                <td><?php echo e($model->prize); ?></td>
                <td><?php echo e($model->venuename); ?></td>
                <td><?php echo e($model->orgname); ?></td>
                <td><?php echo e($model->tcname); ?></td>
                <td><button class="agree"><a href="#open-update<?php echo e($i); ?>">edit</a></button></td>
                <td>
                  <form action="/tourney/remove/<?php echo e($model->id_Tournament); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                    <div>
                      <button class="remove" type="submit">remove</button>
                    </div>
                  </form>
                </td>
                <div id="open-update<?php echo e($i); ?>" class="modal-window">
                  <div class="outside">
                      <div class="inside">
                          <a href="#" title="Close" class="modal-close" style="margin-bottom: 5vh">X</a>
                          <h1>Edit the Tournament!</h1>
                          <form action="/tourney/update/<?php echo e($model->id_Tournament); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <label for="Name">Name</label>
                            <input required type="text" name="name" id="" value="<?php echo e($model->name); ?>">
                            <label for="prize">Prize</label>
                            <input required type="text" name="prize" id="" value="<?php echo e($model->prize); ?>">
                            <label for="venue">Venue</label>
                            <select name="venue" id="">
                                <?php $__currentLoopData = $venue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id_Venue); ?>" <?php echo e(( $model->venuename == $item->name) ? 'selected' : ''); ?>> <?php echo e($item->name); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="organizer">Organizer</label>
                            <select name="organizer" id="">
                                <?php $__currentLoopData = $org; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id_Organizer); ?>" <?php echo e(( $model->orgname == $item->name) ? 'selected' : ''); ?>> <?php echo e($item->name); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="timecontrol">Time Control</label>
                            <select name="timecontrol" id="">
                                <?php $__currentLoopData = $tc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id_Time_Control); ?>" <?php echo e(( $model->tcname == $item->name) ? 'selected' : ''); ?>> <?php echo e($item->name); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input required type="hidden" name="id" value="<?php echo e($model->id_Tournament); ?>">

                            <button type="submit"
                            style="width: 5.5vw;background-color:#28A745;height:2vw;border-radius:1vw;border:none;color:white">Save</button>
                        </form>
                      </div>
                  </div>
              </div>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>


      <a href="/tourney/add" class="act-btn">
        +
      </a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfars\Documents\chesstour\resources\views/tourneylist.blade.php ENDPATH**/ ?>