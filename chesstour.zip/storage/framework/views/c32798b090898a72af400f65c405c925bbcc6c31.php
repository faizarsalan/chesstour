<?php $__env->startSection('content'); ?>
  <h1 class="title">Countries</h1>
        <table id="tablestyle">
          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">Name</th>
              <th scope="col">Capital</th>
              <th scope="col">Actions</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($country->id_Country); ?></td>
                <td><?php echo e($country->name); ?></td>
                <td><?php echo e($country->capital); ?></td>
                <td><button class="agree"><a href="#open-update<?php echo e($i); ?>">edit</a></button></td>
                <td>
                  <form action="/country/remove/<?php echo e($country->id_Country); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                    <div>
                      <button class="remove" type="submit">remove</button>
                    </div>
                  </form>
                </td>
                <div id="open-update<?php echo e($i); ?>" class="modal-window">
                  <div class="outside">
                      <div class="inside">
                          <a href="#" title="Close" class="modal-close" style="margin-bottom: 5vh">X</a>
                          <h1>Edit the Country!</h1>
                          <form action="/country/update/<?php echo e($country->id_Country); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <label for="name">Name</label>
                            <input type="text" name="name" id="" value="<?php echo e($country->name); ?>">
                            <label for="capital">Capital City</label>
                            <input type="text" name="capital" id="" value="<?php echo e($country->capital); ?>">
                            <input type="hidden" name="id" value="<?php echo e($country->id_Country); ?>">

                            <button type="submit"
                            style="width: 5.5vw;background-color:#28A745;height:2vw;border-radius:1vw;border:none;color:white">Save</button>
                        </form>
                      </div>
                  </div>
              </div>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>


      <a href="/country/add" class="act-btn">
        +
      </a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfars\Documents\chesstour\resources\views/countrylist.blade.php ENDPATH**/ ?>